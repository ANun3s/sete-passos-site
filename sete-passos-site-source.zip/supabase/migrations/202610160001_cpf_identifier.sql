ALTER TABLE sete_passos_auth."user" ADD COLUMN cpf text;
ALTER TABLE sete_passos_auth."user" ADD CONSTRAINT user_cpf_digits_check CHECK (cpf IS NULL OR cpf ~ '^[0-9]{11}$');
CREATE UNIQUE INDEX user_cpf_unique_idx ON sete_passos_auth."user" (cpf) WHERE cpf IS NOT NULL;
