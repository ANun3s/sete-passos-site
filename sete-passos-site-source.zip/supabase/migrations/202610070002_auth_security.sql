-- Better Auth uses its own server sessions. Supabase Auth JWTs do not grant
-- access to these tables. Never expose this schema through the Data API.
REVOKE ALL ON SCHEMA sete_passos_auth FROM PUBLIC, anon, authenticated, service_role;
REVOKE ALL ON ALL TABLES IN SCHEMA sete_passos_auth FROM PUBLIC, anon, authenticated, service_role;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA sete_passos_auth FROM PUBLIC, anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA sete_passos_auth REVOKE ALL ON TABLES FROM PUBLIC, anon, authenticated, service_role;

-- No password or login is created here. A separate server-only login can be
-- made a member of this role when the backend connection is configured.
CREATE ROLE sete_passos_backend NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
GRANT USAGE ON SCHEMA sete_passos_auth TO sete_passos_backend;
GRANT SELECT, INSERT, UPDATE, DELETE ON
  sete_passos_auth."user", sete_passos_auth.account,
  sete_passos_auth.session, sete_passos_auth.verification,
  sete_passos_auth."rateLimit" TO sete_passos_backend;

ALTER TABLE sete_passos_auth."user" ENABLE ROW LEVEL SECURITY;
ALTER TABLE sete_passos_auth.account ENABLE ROW LEVEL SECURITY;
ALTER TABLE sete_passos_auth.session ENABLE ROW LEVEL SECURITY;
ALTER TABLE sete_passos_auth.verification ENABLE ROW LEVEL SECURITY;
ALTER TABLE sete_passos_auth."rateLimit" ENABLE ROW LEVEL SECURITY;
CREATE POLICY backend_only ON sete_passos_auth."user" TO sete_passos_backend USING (true) WITH CHECK (true);
CREATE POLICY backend_only ON sete_passos_auth.account TO sete_passos_backend USING (true) WITH CHECK (true);
CREATE POLICY backend_only ON sete_passos_auth.session TO sete_passos_backend USING (true) WITH CHECK (true);
CREATE POLICY backend_only ON sete_passos_auth.verification TO sete_passos_backend USING (true) WITH CHECK (true);
CREATE POLICY backend_only ON sete_passos_auth."rateLimit" TO sete_passos_backend USING (true) WITH CHECK (true);

CREATE INDEX session_expiry_idx ON sete_passos_auth.session ("expiresAt");
CREATE INDEX verification_expiry_idx ON sete_passos_auth.verification ("expiresAt");
CREATE INDEX rate_limit_expiry_idx ON sete_passos_auth."rateLimit" ("lastRequest");
COMMENT ON SCHEMA sete_passos_auth IS 'Sete Passos: private Better Auth login database. Server access only; no clinical data.';
