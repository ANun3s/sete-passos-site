CREATE TABLE sete_passos_auth.clinical_ficha (
  id text PRIMARY KEY,
  "userId" text NOT NULL REFERENCES sete_passos_auth."user" (id) ON DELETE CASCADE,
  "createdBy" text REFERENCES sete_passos_auth."user" (id) ON DELETE SET NULL,
  title text NOT NULL CHECK (length(btrim(title)) BETWEEN 1 AND 160),
  type text NOT NULL CHECK (type IN ('avaliacao-fisioterapeutica', 'proposta-tratamento', 'outro')),
  content jsonb NOT NULL CHECK (jsonb_typeof(content) = 'object' AND jsonb_typeof(content->'text') = 'string'),
  "createdAt" timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE sete_passos_auth.clinical_ficha ENABLE ROW LEVEL SECURITY;
CREATE POLICY backend_only ON sete_passos_auth.clinical_ficha
  TO sete_passos_backend USING (true) WITH CHECK (true);
REVOKE ALL ON sete_passos_auth.clinical_ficha FROM PUBLIC, anon, authenticated, service_role;
GRANT SELECT, INSERT ON sete_passos_auth.clinical_ficha TO sete_passos_backend;

CREATE INDEX clinical_ficha_user_created_idx
  ON sete_passos_auth.clinical_ficha ("userId", "createdAt" DESC);

COMMENT ON TABLE sete_passos_auth.clinical_ficha IS
  'Sensitive individual records. Private backend-only storage linked to Better Auth profiles.';
