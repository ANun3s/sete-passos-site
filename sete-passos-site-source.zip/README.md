# Sete Passos — front-end

Site local de Sete Passos — Físio e Estética Avançada, com início institucional, capa de login e biblioteca visual de fichas. Implementado diretamente nesta pasta, aberta no VS Code.

## Desenvolvimento
```sh
npm install
npm run dev
```
Servidor: `http://127.0.0.1:5177`. O script usa porta fixa para não abrir silenciosamente uma porta diferente.

### Go Live no VS Code
O Go Live serve a pasta compilada `dist`, configurada em `.vscode/settings.json`, para que módulos JSX/React e os demais arquivos Vite funcionem no Live Server. Antes de abrir ou atualizar o site após editar o código, execute `npm run build`. Se o Go Live já estiver aberto após uma mudança nas configurações, pare e inicie o servidor novamente.

Teste da instância real, com Go Live aberto na porta 5500:
```sh
GO_LIVE_URL=http://127.0.0.1:5500 npm test -- tests/go-live.spec.js
```

## Verificação e build
```sh
npx playwright install chromium
npm test
npm run check
npm run build
npm run preview
```
A prévia do build usa `http://127.0.0.1:4177`. O resultado publicável é `dist/`. Site e API publicados em [sete-passos.pages.dev](https://sete-passos.pages.dev). O botão Google está renderizado; o Google Cloud ainda precisa autorizar a origem de produção para concluir o fluxo de login. Node verificado neste ambiente: 26.7.0.

## Onde editar
- `index.html`: textos, estrutura das seções, logo e diálogo.
- `src/styles.css`: tokens, composição, Liquid Glass e responsividade.
- `src/navigation.js` / `.css`: menu mobile e teclado.
- `src/motion.js` / `.css`: aurora ligada ao ponteiro, revelações, parallax e progresso.
- `src/logo.js` / `.css`: logo centralizada, tilt 3D e contorno que segue o mouse.
- `src/footer.css`: rodapé monumental azul-marinho e navegação responsiva.
- `src/contact.js` / `.css`: painel demonstrativo e cópia local de mensagem.
- `public/assets`: logo original e derivações otimizadas.
- `public/fonts`: fontes locais e respectivas licenças OFL.
- `AGENTS.md` e `DESIGN-SYSTEM.md`: diretrizes desta identidade.
- `tests/`: testes Playwright de comportamento e auditoria axe.
- `artifacts/`: capturas e evidências da verificação visual.

## O que funciona
Navegação por âncoras e teclado; menu mobile; acordeões nativos; botões transparentes com aurora azul/ciano seguindo o mouse; foco e estados de pressão; revelações na rolagem; parallax pequeno na marca; progresso de leitura; preferências de movimento reduzido; diálogo com foco cíclico; mensagem gerada e copiada localmente, inclusive alternativa manual quando clipboard é negado.

Sem JavaScript, o conteúdo, a navegação, os acordeões e o aviso de contato continuam acessíveis. Fontes, logo e código são locais: nenhuma CDN é necessária em runtime.

## Refinamento de interação — princípios Apple
Aplicado à identidade existente, sem migrar a stack nem substituir a marca:
- `src/interface.css`: leitura mais confortável, fichas em uma superfície agrupada, seleção visível da página, pressão de 80ms, ações desativadas sem feedback enganoso e um único nível de blur no header.
- `src/spring.js`: solução analítica de mola criticamente amortecida, com velocidade independente por eixo; para quando chega ao repouso. `to()` muda somente o destino; `jump()` é a alternativa imediata; `stop()` cancela o frame pendente.
- `src/logo.js`: resposta `.35` segundos; mantém posição e velocidade ao redirecionar ou sair do hover, sem uma segunda transição CSS sobre o transform.
- `src/navigation.js`: resposta `.3` segundos; menu ancorado no botão, reversível durante entrada/saída, Escape e foco. Ao fechar o contato aberto pelo menu móvel, o foco retorna ao botão do menu, não ao link agora oculto/inert. Em telas baixas, o limite de altura usa a borda real do header; o conteúdo rola verticalmente. Eventos, observer e frames são limpos na troca de página.
- `prefers-reduced-motion`: sem molas/translações, inclusive ao mudar a preferência com o menu aberto. `prefers-reduced-transparency` e `prefers-contrast: more`: materiais sólidos e contornos legíveis quando o navegador expõe essas preferências.
- Texto ampliado a 200% não causa rolagem horizontal nem recorta os textos testados; as fichas permanecem apenas demonstrativas.

DM Sans e Instrument Serif continuam locais por fazerem parte da identidade Sete Passos. Não há fontes, bibliotecas de animação ou serviços novos.

Para ajustar as molas, altere `response` no componente correspondente. É um parâmetro da resposta física, não uma duração fixa. Exemplo usando a mesma implementação:
```js
import { createSpring } from './src/spring.js';
const marker = document.querySelector('[data-marker]');
const movement = createSpring({ x: 0 }, ({ x }) => {
  marker.style.transform = `translateX(${x}px)`;
}, { response: .35 });
movement.to({ x: 80 });
// Chamadas posteriores a to() preservam a posição e a velocidade atuais.
```

Os testes `tests/apple-*.spec.js` aceitam `PORTAL_BASE_URL` para validar o mesmo comportamento no Go Live e no build. `scripts/verify-pages.mjs` inclui esses testes nos três servidores. `node scripts/verify-apple.mjs after` captura Início/Login/Fichas em quatro larguras no Go Live; a evidência fica em `artifacts/apple/`. O backup anterior está em `artifacts/backups/before-apple-refinement-*.zip`.

## Limites deliberados
- Não existe backend, envio de formulário, agendamento real, WhatsApp ou coleta de dados.
- Apenas nome, segmento e logo foram fornecidos. Os textos institucionais são propostas editoriais para aprovação, não descrição validada de protocolos clínicos.
- Endereço, horários, equipe, credenciais, lista de procedimentos e contatos devem ser confirmados pela clínica antes de publicação.
- Não foram inventados preços, depoimentos, resultados, profissionais nem métricas.
- A logo original foi preservada. O símbolo do cabeçalho é um recorte do arquivo fornecido, não um redesenho.

## Revisão visual
Paleta branco/azul-marinho; abertura e cabeçalhos centralizados; tipografia DM Sans + Instrument Serif. Logo original com profundidade, inclinação e contorno luminoso responsivos ao mouse, com alternativa estática para toque/movimento reduzido. O rodapé adapta a composição global do site do Hermes, sem copiar sua marca ou ilustração. Listas e textos longos preservam alinhamento legível. O vidro e a aurora foram usados porque fazem parte do pedido, não como decoração em todas as superfícies.

O anexo de Aura orientou o tratamento de vidro e a composição central, sem trocar a identidade do projeto, migrar a stack ou adicionar backend, planos e depoimentos fictícios. Referência e capturas ficam em `artifacts/references/` e `artifacts/refinement/`. A versão anterior foi preservada em `artifacts/backups/`.

## Novas páginas: login e fichas
- `index.html`: início institucional com acesso **Login**; fichas ficam dentro da Administração.
- `login.html`: entrada da conta. A sessão é autenticada pelo backend local.
- `perfil.html`: informações e segurança da conta autenticada.
- `admin.html`: área restrita à conta indicada por `SETE_PASSOS_ADMIN_EMAIL` no arquivo privado `supabase.env`. A biblioteca de fichas fica dentro desta área; conteúdo e prévias são lidos por endpoints autenticados.
- `fichas.html`: compatibilidade com links antigos; redireciona para a seção Fichas dentro da Administração e não contém os modelos.

No Go Live: `http://127.0.0.1:5500/login.html`. A Administração aparece no menu da conta somente para o e-mail autorizado. O backend valida a sessão e o e-mail em cada requisição às fichas e prévias; os arquivos ficam fora do diretório público. A autorização é local e não altera o schema remoto do Supabase.

Em **Pessoas e acessos**, selecione o nome do cliente para abrir as informações da conta e todas as fichas preenchidas. A profissional pode registrar os modelos de avaliação fisioterapêutica, proposta de tratamento ou outra ficha, com os dados organizados por seção e vinculados ao perfil selecionado. Consulte [o fluxo e os campos](docs/admin-client-fichas.md).

### Arquivos criados ou alterados nesta ampliação
| Arquivo | Situação / responsabilidade |
| --- | --- |
| `login.html`, `perfil.html`, `admin.html`, `fichas.html` | Entrada e áreas da conta; Fichas é um redirecionamento legado para a área administrativa protegida. |
| `src/portal.css` | Novo layout de login, biblioteca, prévias e rodapé interno. |
| `src/page-curtain.js` | Novo controlador: rotas, estado pendente, troca de documento e histórico. |
| `src/curtain-effect.js` | Nova função pura de direção, geometria e animação da cortina. |
| `src/page-document.js` | Novo carregador de HTML local, com validação e timeout. |
| `src/page-curtain.css` | Nova camada visual da transição e fallback. |
| `vite.config.js` | Novo build multipágina, com as três entradas HTML. |
| `index.html` | Menu, wrapper de conteúdo, cortina e região de anúncios. |
| `src/main.js` | Montagem por página e configuração da transição. |
| `src/navigation.js`, `src/motion.js`, `src/logo.js` | Desmontagem dos eventos/observers por AbortSignal; âncoras separadas das rotas. |
| `src/contact.js` | Fecha o contato na navegação sem restaurar foco sobre uma transição pendente. |
| `package.json` | Verificação de sintaxe inclui os novos módulos; sem novas dependências. |
| `tests/portal*.spec.js`, `tests/records.spec.js`, `tests/curtain*.spec.js`, `tests/history*.spec.js` | Novos testes do portal, tipografia, cortina, acessibilidade, fallback e histórico. |
| `tests/navigation-edge.spec.js`, `playwright.config.js` | Regressões da revisão em servidores reais; artefatos isolados do live reload. |
| `scripts/verify-pages.mjs` | Valida Go Live, Vite e build real; produz screenshots e relatório. |
| `AGENTS.md`, `DESIGN-SYSTEM.md`, `tasks/pages-spec.md`, `tasks/plan.md`, `tasks/todo.md`, `README.md` | Escopo, decisões, operação e critérios de entrega. |

Os fontes acima contêm o código completo; os comentários explicam cobertura da tela, troca de DOM, limpeza dos eventos e limites deliberados do protótipo. Evidências geradas ficam em `artifacts/pages/` e o build em `dist/`. Um backup pré-alteração está em `artifacts/backups/before-pages-*.zip`.

### Como a cortina está integrada
O projeto continua em **HTML/CSS/JavaScript**, sem migração para React. `createPageCurtain()` é o equivalente nativo ao hook sugerido no anexo. Retorna `page`, `isPending`, `go(next)` e `ref` (além da desmontagem). Os índices são **0: Início, 1: Login, 2: Fichas**.

- O `<body class="page-curtain-stage">` contém `#page-content`, a cortina e uma região `aria-live="polite"` persistente. O recorte fica somente na cortina fixa para não quebrar o header sticky.
- Cada HTML inclui os mesmos estilos e o mesmo `src/main.js`. Links continuam tendo URLs reais; o menu existente exerce o papel de navegação por páginas.
- Um clique comum numa rota conhecida carrega o HTML local, cobre a página, troca `#page-content` quando a cortina está totalmente opaca e revela o destino. Só `clip-path`, `transform` e `opacity` são animados.
- `pageCurtainDirection(current, next)` retorna `left` ao avançar na ordem e `right` ao voltar.
- Durante a troca, o conteúdo fica `inert` e `aria-busy`, e qualquer diálogo aberto é fechado. Cliques repetidos são ignorados; Voltar/Avançar cancela a navegação pendente antes de um `pushState` obsoleto, preservando o destino mais recente.
- Ao concluir, o título da aba muda, o h1 recebe foco e é anunciado “Navegou para [página]”. Links para uma seção, como `#cuidado`, focam a própria seção para manter o próximo Tab no destino escolhido. Fragmentos inválidos retornam ao título sem interromper o anúncio. A página ativa tem `aria-current="page"`.
- Links com modificadores, download, nova aba e âncoras da página conservam seu comportamento nativo.

**Decisão:** HTML multipágina com aprimoramento progressivo mantém Go Live, URLs diretas e navegação sem JS. React Router e uma biblioteca de animação não são necessários para esse escopo. A referência é o comportamento do PageCurtain do Motion UI (`https://motion.dev/ui/components/page-curtain`), implementado aqui com APIs nativas, sem copiar o componente proprietário.

### Ajustar ângulo, duração, easing e cores
Em `src/main.js`:
```js
createPageCurtain({
  mount: mountPage,
  angle: 9,                // graus; a geometria limita a faixa de 0 a 20
  duration: 780,           // milissegundos totais de animação; ex.: 600 a 900
  easing: 'cubic-bezier(.76, 0, .24, 1)',
});
```
A duração se divide igualmente entre cobertura e revelação; o carregamento do HTML acontece antes da animação. Use `titles: ['Início', 'Login', 'Fichas']` para substituir os títulos exibidos sem renomear URLs. O índice inicial é detectado pelo `data-page` do HTML; `initial` permite definição explícita.

Em `src/page-curtain.css`:
```css
:root {
  --curtain-color: var(--navy);
  --curtain-text: var(--white);
}
```
O título usa a Instrument Serif local. Preserve contraste ao trocar as cores. Para adicionar uma página, crie seu HTML com a mesma estrutura, registre `key/path/title` em `routes` (`src/page-curtain.js`), acrescente a entrada em `vite.config.js` e atualize os links/`aria-current` dos documentos.

### Fallbacks e movimento reduzido
- **Com View Transitions:** `document.startViewTransition()` faz a troca sob a cortina; os pseudo-elementos `::view-transition-old/new` não adicionam um segundo fade.
- **Sem View Transitions:** a cortina continua com Web Animations + CSS; o DOM troca sob cobertura total.
- **Sem Web Animations:** troca instantânea e foco preservado.
- **Movimento reduzido:** troca instantânea, sem cortina nem snapshots.
- **Sem JavaScript:** navegação normal entre arquivos e modelos abertos por `<details>`; não há dependência do controlador.
- **Falha de carregamento:** a página atual é liberada e um aviso permite repetir a navegação. Uma falha durante Voltar/Avançar recorre à navegação nativa para não manter URL e documento divergentes.

### Reproduzir a verificação
```sh
GO_LIVE_URL=http://127.0.0.1:5500 npm test
npm run check
npm run build
node scripts/verify-pages.mjs
npm audit --audit-level=high
```
O script espera Go Live em 5500 e Vite em 5177. Ele inicia e encerra sozinho uma prévia local do build numa porta disponível e executa as regressões da revisão nos três servidores. Capturas ficam em memória durante as verificações e só são gravadas após fechar o navegador, evitando reloads do Live Server.

Para executar somente as regressões contra o Go Live:
```sh
PORTAL_BASE_URL=http://127.0.0.1:5500 npm test -- tests/navigation-edge.spec.js
```
Com `PORTAL_BASE_URL` ou `GO_LIVE_URL`, traces e relatório HTML do Playwright ficam em `os.tmpdir()/sete-passos-playwright`, fora do workspace observado pelo Live Server. Isso mantém os traces ativos sem provocar recargas no meio dos testes.

A aplicação não usa armazenamento local/de sessão para dados. O próprio Live Server adiciona a flag de desenvolvimento `IsThisFirstTime_Log_From_LiveServer`; a verificação aceita somente essa chave na instância Go Live.

## Organização e rolagem nativa — 14/10/2026

A pedido do usuário, foram removidos os controladores de scroll, a pilha de cards, a barra de progresso e as revelações. As seções usam fluxo normal. A seção “Nosso cuidado” usa a pasta do React Bits com cinco miniaturas; o card escolhido cresce em uma superfície dentro da página, sem modal. GSAP Core permanece nos menus e no diálogo de contato; ScrollTrigger não controla essa seção. Os controladores e testes antigos ficam preservados em `docs/archive/scroll-motion/`, fora do runtime e da suíte ativa.

Revisão visual e referências: `docs/design-review-2026-10-14.md`. Cobertura nova: `tests/native-flow.spec.js` e `tests/organized-portal.spec.js`. Nenhuma mudança no backend ou nas permissões de acesso nesta revisão.
