# Histórico da rolagem animada

Em 14/10/2026, o usuário pediu remoção das animações de scroll. Estes controladores e testes documentam o comportamento anterior (pin, scrub, pilha e revelações). Não fazem parte do runtime nem da suíte atual.

A cobertura ativa está em `tests/native-flow.spec.js`, com testes de estabilidade, âncoras, restauração após reload e texto ampliado; as suítes de qualidade, navegação, teclado e portal continuam ativas.
