// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177', viewport: { width: 1440, height: 900 } });
for (const [route, panel, needle] of [['/', '#cuidado', 'Escutar antes de tudo.']]) {
  test(`busca revela todo o texto parcialmente coberto em ${route}`, async ({ page }) => {
    await page.goto(route);
    await page.evaluate(() => document.fonts.ready);
    await expect(page.locator(panel)).toHaveAttribute('data-care-layout', 'deck');
    await page.evaluate(async () => {
      const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
      const trigger = ScrollTrigger.getById('sete-passos-care');
      scrollTo({ top: trigger.start + (trigger.end - trigger.start) * .53, behavior: 'instant' });
    });
    await page.waitForTimeout(650);
    expect(await page.evaluate(text => { getSelection().removeAllRanges(); return window.find(text); }, needle)).toBe(true);
    await expect(page.locator(panel)).toHaveAttribute('data-care-phase', 'open');
    expect(await page.evaluate(() => getSelection().toString())).toBe(needle);
    expect(await page.evaluate(() => {
      const range = getSelection().getRangeAt(0);
      const target = range.startContainer.parentElement;
      for (let i = range.startOffset; i < range.endOffset; i++) {
        const char = new Range(); char.setStart(range.startContainer, i); char.setEnd(range.startContainer, i + 1);
        const r = char.getBoundingClientRect();
        if (!target.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2))) return false;
      }
      return true;
    })).toBe(true);
  });
}
