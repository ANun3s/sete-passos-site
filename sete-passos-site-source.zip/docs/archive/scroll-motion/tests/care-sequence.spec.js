// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });
async function jump(page, top) {
  await page.evaluate(y => scrollTo({ top: y, behavior: 'instant' }), top);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return Boolean(ScrollTrigger.getById('sete-passos-care')?.getTween()?.isActive());
  })).toBe(false);
}
async function snapshot(page) {
  return page.evaluate(() => {
    const care = document.querySelector('[data-care-scene]');
    return { y: care.getBoundingClientRect().y, bottom: care.getBoundingClientRect().bottom, viewport: innerHeight, scale: new DOMMatrix(getComputedStyle(care).transform).a,
      phase: care.dataset.carePhase, next: document.querySelector('#essencia').getBoundingClientRect().top };
  });
}

test('abertura dos quatro cards termina antes do empilhamento seguinte', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const { start, end, hold } = await page.evaluate(async () => {
    const { layoutTop } = await import('/src/scroll-position.js');
    const panel = document.querySelector('#cuidado');
    const pin = Math.min(document.querySelector('.site-header').offsetHeight + 16, innerHeight - panel.offsetHeight - 24);
    return { start: layoutTop(panel) - pin,
      end: Number(panel.querySelector('[data-care-cards]').dataset.scrollRevealAt),
      hold: parseFloat(getComputedStyle(panel.parentElement).paddingBottom) };
  });
  await jump(page, start);
  const initial = await snapshot(page);
  expect(initial.phase).toBe('stacked');
  for (const top of [(start + end) / 2, end, start + hold - 1]) {
    await jump(page, top);
    const scene = await snapshot(page);
    expect(scene.y).toBeCloseTo(initial.y, 1);
    expect(scene.scale).toBe(1);
    // The completed deck retains a bottom breathing margin. Its successor can
    // enter that empty margin, but must not cover the deck during its hold.
    // While cards are still opening, it must remain outside the viewport.
    expect(scene.next).toBeGreaterThanOrEqual(scene.phase === 'open' ? scene.bottom : scene.viewport);
  }
  expect((await snapshot(page)).phase).toBe('open');
  await jump(page, start + hold + 400);
  const resumed = await snapshot(page);
  expect(resumed.next).toBeLessThan(700);
  expect(resumed.scale).toBeLessThan(1);
  await jump(page, start);
  expect((await snapshot(page)).phase).toBe('stacked');
});
