// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });


async function jump(page, top) {
  await page.evaluate(y => window.scrollTo({ top: y, behavior: 'instant' }), top);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
}

test('as seções inteiras formam uma pilha reversível na rolagem da janela', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  const panels = page.locator('.scroll-stack-card');
  await expect(panels).toHaveCount(5);
  const nextTop = await page.locator('[data-stack-slot]').nth(1).evaluate(el => el.getBoundingClientRect().top + scrollY);
  const position = nextTop - 380;
  await jump(page, position);
  const first = await panels.nth(0).boundingBox();
  const next = await panels.nth(1).boundingBox();
  expect(next.width).toBeGreaterThan(1300);
  expect(next.y).toBeLessThan(first.y + first.height - 150);
  expect(await panels.nth(0).evaluate(el => new DOMMatrix(getComputedStyle(el).transform).a)).toBeLessThan(1);
  expect(await panels.nth(1).evaluate(el => {
    const r = el.getBoundingClientRect();
    return el.contains(document.elementFromPoint(innerWidth / 2, r.top + 25));
  })).toBe(true);
  const transform = await panels.nth(0).evaluate(el => el.style.transform);
  await jump(page, position + 240);
  await jump(page, position);
  expect(await panels.nth(0).evaluate(el => el.style.transform)).toBe(transform);
  await jump(page, 0);
  await expect(page.locator('#hero-title')).toBeInViewport();
  expect(await panels.nth(0).evaluate(el => new DOMMatrix(getComputedStyle(el).transform).a)).toBe(1);
});
