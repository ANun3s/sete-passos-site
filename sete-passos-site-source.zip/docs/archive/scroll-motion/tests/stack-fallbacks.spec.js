// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';
import AxeBuilder from '@axe-core/playwright';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });
const countTriggers = page => page.evaluate(async () => (await import('/src/vendor/gsap.mjs')).ScrollTrigger.getAll().length);
const settle = async page => {
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return Boolean(ScrollTrigger.getById('sete-passos-care')?.getTween()?.isActive());
  })).toBe(false);
};

for (const width of [320, 768, 1024, 1440]) {
  test(`cards e seções continuam legíveis sem overflow em ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 960 });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('/#cuidado');
    await page.evaluate(() => document.fonts.ready);
    await settle(page);
    await expect(page.locator('.care-card')).toHaveCount(4);
    for (const y of [0, 550, 950, 1400, 2300]) {
      await page.evaluate(top => scrollTo({ top, behavior: 'instant' }), y);
      await settle(page);
      expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(1);
      const outside = await page.locator('.care-card').evaluateAll(cards => cards.some(card => {
        const r = card.getBoundingClientRect(); return r.x < -1 || r.right > innerWidth + 1;
      }));
      expect(outside).toBe(false);
    }
    await page.locator('.footer-links a[href="#cuidado"]').click();
    await expect.poll(() => page.locator('#cuidado .section-heading').evaluate(el => getComputedStyle(el).opacity)).toBe('1');
    await page.evaluate(() => {
      const at = document.querySelector('[data-care-cards]').dataset.scrollRevealAt;
      if (at !== undefined) scrollTo({ top: Number(at), behavior: 'instant' });
    });
    await settle(page);
    // Audit the live card chapter after its entrance settles; full-page reduced-motion scans exist in quality.spec.js.
    const scan = await new AxeBuilder({ page }).include('#cuidado').withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(scan.violations).toEqual([]);
    expect(errors).toEqual([]);
  });
}

test('movimento reduzido ao vivo desmonta a pilha e as molas sem esconder conteúdo', async ({ page }) => {
  await page.goto('/#cuidado');
  await expect.poll(() => countTriggers(page)).toBe(2);
  await page.evaluate(() => scrollBy({ top: 400, behavior: 'instant' }));
  await settle(page);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await expect(page.locator('[data-scroll-stack]')).toHaveAttribute('data-stack-active', 'false');
  await expect.poll(() => countTriggers(page)).toBe(0);
  expect(await page.locator('[data-care-scene]').evaluate(el => getComputedStyle(el.parentElement).paddingBottom)).toBe('0px');
  const transforms = await page.locator('.scroll-stack-card, .care-card, .tilted-card-inner').evaluateAll(els => els.map(el => getComputedStyle(el).transform));
  expect(transforms.every(value => value === 'none')).toBe(true);
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await expect.poll(() => countTriggers(page)).toBe(2);
});

test('texto ampliado a 200% remove o pin e mantém os textos e ações completos', async ({ page }) => {
  await page.goto('/#cuidado');
  await page.addStyleTag({ content: 'html { font-size: 200% !important; }' });
  await expect(page.locator('[data-scroll-stack]')).toHaveAttribute('data-stack-active', 'false');
  await expect.poll(() => countTriggers(page)).toBe(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(1);
  for (const card of await page.locator('.care-card').all()) {
    expect(await card.evaluate(el => el.scrollWidth <= el.clientWidth + 1)).toBe(true);
    await expect(card.locator('.area-link')).toBeVisible();
  }
});

test('cortina remonta os controladores de seção e cards sem acumular triggers', async ({ page }) => {
  await page.goto('/');
  for (let i = 0; i < 3; i++) {
    await expect.poll(() => countTriggers(page)).toBe(2);
    await page.locator('#main-nav a[href="/login.html"]').click();
    await expect(page.locator('#page-content')).toHaveAttribute('data-page', 'login');
    await expect(page.locator('#page-content')).toHaveAttribute('aria-busy', 'false');
    await expect.poll(() => countTriggers(page)).toBe(0);
    await page.locator('#main-nav a[href="/index.html"]').click();
    await expect(page.locator('#page-content')).toHaveAttribute('data-page', 'inicio');
    await expect(page.locator('#page-content')).toHaveAttribute('aria-busy', 'false');
  }
  await expect.poll(() => countTriggers(page)).toBe(2);
});

test('resize durante o deslocamento recalcula os limites sem recortar os cards', async ({ page }) => {
  await page.goto('/#cuidado');
  await page.evaluate(() => scrollBy({ top: 400, behavior: 'instant' }));
  for (const width of [1024, 768, 320, 1440]) {
    await page.setViewportSize({ width, height: 960 });
    await settle(page);
    expect(await page.evaluate(() => document.documentElement.scrollWidth - innerWidth)).toBeLessThanOrEqual(1);
    expect(await page.locator('.care-card').evaluateAll(cards => cards.every(el => {
      const r = el.getBoundingClientRect(); return r.left >= -1 && r.right <= innerWidth + 1;
    }))).toBe(true);
  }
});
