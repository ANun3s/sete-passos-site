// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });

test('GSAP é o único coordenador da rolagem das seções', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('[data-scroll-stack]')).toHaveAttribute('data-scroll-engine', 'gsap');
  await expect(page.locator('html')).not.toHaveClass(/lenis/);
});

test('indicador de navegação usa a posição real da seção dentro da pilha', async ({ page }) => {
  await page.goto('/');
  const care = page.locator('#main-nav a[href="#cuidado"]');
  await expect(care).not.toHaveAttribute('aria-current', 'location');
  await care.click();
  await expect(care).toHaveAttribute('aria-current', 'location');
  await page.locator('.brand').click();
  await expect.poll(() => page.evaluate(() => scrollY)).toBeLessThan(2);
  await expect(care).not.toHaveAttribute('aria-current', 'location');
});
