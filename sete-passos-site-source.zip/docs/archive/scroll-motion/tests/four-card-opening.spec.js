// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });

async function jump(page, top) {
  await page.evaluate(y => scrollTo({ top: y, behavior: 'instant' }), top);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return Boolean(ScrollTrigger.getById('sete-passos-care')?.getTween()?.isActive());
  })).toBe(false);
}
async function geometry(page) {
  return page.locator('[data-care-card]').evaluateAll(cards => cards.map(card => {
    const r = card.getBoundingClientRect();
    const m = new DOMMatrix(getComputedStyle(card).transform);
    return { x: r.x + r.width / 2, y: r.y + r.height / 2, width: r.width, height: r.height,
      scale: Math.hypot(m.a, m.b), angle: Math.atan2(m.b, m.a) * 180 / Math.PI };
  }));
}

test('pilha abre em quatro cantos com escala, rotações opostas e reversão exata', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const { start, end } = await page.evaluate(async () => {
    const { layoutTop } = await import('/src/scroll-position.js');
    const panel = document.querySelector('#cuidado');
    const pin = Math.min(document.querySelector('.site-header').offsetHeight + 16, innerHeight - panel.offsetHeight - 24);
    return { start: layoutTop(panel) - pin, end: Number(panel.querySelector('[data-care-cards]').dataset.scrollRevealAt) };
  });
  expect(end).toBeGreaterThan(start + 700);
  await jump(page, start);
  const closed = await geometry(page);
  expect(await page.locator('#care-title').evaluate(el => el.getBoundingClientRect().top)).toBeGreaterThanOrEqual(
    await page.locator('.site-header').evaluate(el => el.getBoundingClientRect().bottom)
  );
  for (let i = 1; i < 4; i++) {
    expect(closed[i].x).toBeGreaterThan(closed[i - 1].x);
    expect(closed[i].x - closed[i - 1].x).toBeLessThan(24);
    expect(closed[i].y).toBeLessThan(closed[i - 1].y);
    expect(closed[i - 1].y - closed[i].y).toBeLessThan(24);
  }
  await jump(page, (start + end) / 2);
  const middle = await geometry(page);
  await jump(page, end);
  const opened = await geometry(page);
  const centerX = opened.reduce((sum, card) => sum + card.x, 0) / 4;
  const centerY = opened.reduce((sum, card) => sum + card.y, 0) / 4;
  for (let i = 0; i < 4; i++) {
    expect(opened[i].scale).toBeGreaterThanOrEqual(.78);
    expect(opened[i].scale).toBeLessThanOrEqual(.86);
    expect(Math.abs(opened[i].x - centerX)).toBeGreaterThan(180);
    expect(Math.abs(opened[i].y - centerY)).toBeGreaterThan(100);
    expect(Math.abs(middle[i].x - closed[i].x)).toBeLessThanOrEqual(Math.abs(opened[i].x - closed[i].x) + .1);
    expect(Math.abs(opened[i].angle)).toBeGreaterThan(1);
    expect(Math.abs(opened[i].angle)).toBeLessThan(9);
    expect(i % 2 ? opened[i].x > centerX && opened[i].angle > 0 : opened[i].x < centerX && opened[i].angle < 0).toBe(true);
    expect(i < 2 ? opened[i].y < centerY : opened[i].y > centerY).toBe(true);
  }
  expect(await page.locator('#essencia').evaluate(el => el.getBoundingClientRect().top)).toBeGreaterThanOrEqual(960);
  await jump(page, (start + end) / 2);
  const reversedMiddle = await geometry(page);
  for (let i = 0; i < 4; i++) {
    expect(reversedMiddle[i].x).toBeCloseTo(middle[i].x, 1);
    expect(reversedMiddle[i].y).toBeCloseTo(middle[i].y, 1);
  }
  await jump(page, start);
  const reversed = await geometry(page);
  for (let i = 0; i < 4; i++) {
    expect(reversed[i].x).toBeCloseTo(closed[i].x, 1);
    expect(reversed[i].y).toBeCloseTo(closed[i].y, 1);
    expect(reversed[i].scale).toBeCloseTo(closed[i].scale, 3);
  }
});

test('foco em um card da pilha abre a composição e revela sua ação', async ({ page }) => {
  await page.goto('/#cuidado');
  await page.evaluate(() => document.fonts.ready);
  const action = page.locator('[data-care-card]').nth(3).locator('a');
  await action.focus({ preventScroll: true });
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-phase', 'open');
  await expect.poll(() => action.evaluate(el => {
    const r = el.getBoundingClientRect();
    return el.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2));
  })).toBe(true);
});

test('abertura em 900px de altura mantém título e ações fora do cabeçalho', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const end = await page.locator('[data-care-cards]').evaluate(el => Number(el.dataset.scrollRevealAt));
  await jump(page, end);
  const headerBottom = await page.locator('.site-header').evaluate(el => el.getBoundingClientRect().bottom);
  expect(await page.locator('#care-title').evaluate(el => el.getBoundingClientRect().top)).toBeGreaterThanOrEqual(headerBottom);
  for (const action of await page.locator('[data-care-card] .area-link').all()) {
    expect(await action.evaluate(el => el.getBoundingClientRect().bottom)).toBeLessThan(900);
  }
});

test('impressão revela todos os cards e restaura a abertura ao voltar à tela', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  await page.emulateMedia({ media: 'print' });
  await expect.poll(() => page.locator('[data-care-card]').evaluateAll(cards => {
    const boxes = cards.map(card => card.getBoundingClientRect());
    return boxes.every((a, i) => boxes.slice(i + 1).every(b =>
      a.right <= b.left || b.right <= a.left || a.bottom <= b.top || b.bottom <= a.top));
  })).toBe(true);
  await expect(page.locator('[data-scroll-stack]')).toHaveAttribute('data-stack-active', 'false');
  await expect(page.locator('.site-header')).toBeHidden();
  await expect(page.locator('.skip-link')).toBeHidden();
  await page.emulateMedia({ media: 'screen' });
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return ScrollTrigger.getAll().map(trigger => trigger.vars.id).sort();
  })).toEqual(['sete-passos-care', 'sete-passos-scroll']);
});

test('quatro cards reutilizam as duas áreas e os princípios existentes', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  const cards = page.locator('[data-care-card]');
  await expect(cards).toHaveCount(4);
  await expect(cards.locator('h3')).toHaveText(['Fisioterapia', 'Estética avançada', 'Escutar antes de tudo.', 'Respeitar o seu ritmo.']);
  for (const card of await cards.all()) {
    await expect(card.locator('.care-card-description')).not.toBeEmpty();
    await expect(card.locator('a')).toHaveCount(1);
  }
});
