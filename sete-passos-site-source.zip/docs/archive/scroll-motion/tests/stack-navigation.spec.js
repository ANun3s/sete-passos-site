// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });
async function visibleTop(page, selector) {
  await expect.poll(() => page.locator(selector).evaluate(el => {
    const r = el.getBoundingClientRect();
    const header = document.querySelector('.site-header').getBoundingClientRect().bottom;
    return r.top >= header - 1 && r.top < innerHeight - 100;
  })).toBe(true);
}

test('âncoras regressam a Cuidado e Essência mesmo com a pilha já atravessada', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await page.locator('.footer-back').scrollIntoViewIfNeeded();
  await page.locator('.footer-links a[href="#cuidado"]').click();
  await visibleTop(page, '#care-title');
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-phase', 'stacked');
  const left = await page.locator('.care-card').first().boundingBox();
  expect(left.x).toBeGreaterThan(250);
  await page.locator('.footer-back').scrollIntoViewIfNeeded();
  await page.locator('.footer-links a[href="#essencia"]').click();
  await visibleTop(page, '#essence-title');
});

test('busca textual revela o título selecionado mesmo atrás de outra seção', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => scrollTo({ top: 3300, behavior: 'instant' }));
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  expect(await page.evaluate(() => window.find('Fisioterapia'))).toBe(true);
  await expect.poll(() => page.locator('#physio-title').evaluate(el => {
    const r = el.getBoundingClientRect();
    return el.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2));
  })).toBe(true);
  expect(await page.evaluate(() => getSelection().toString())).toBe('Fisioterapia');
});

test('Tab não deixa ações cobertas pela próxima seção', async ({ page }) => {
  await page.goto('/');
  await page.locator('.hero [data-contact]').focus();
  for (let i = 0; i < 9; i++) {
    await page.keyboard.press('Tab');
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const visible = await page.evaluate(() => {
      const el = document.activeElement;
      const r = el.getBoundingClientRect();
      const top = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
      return el.contains(top) || top?.contains(el);
    });
    expect(visible).toBe(true);
  }
});
