// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({
  baseURL: process.env.PORTAL_BASE_URL || process.env.GO_LIVE_URL || 'http://127.0.0.1:5177',
  viewport: { width: 1440, height: 960 },
  reducedMotion: 'no-preference',
});

async function settledState(page) {
  await page.evaluate(() => document.fonts.ready);
  // Observe real startup refreshes and the .45s scrub; do not repair scroll in the test.
  await page.waitForTimeout(700);
  return page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    const trigger = ScrollTrigger.getById('sete-passos-care');
    const root = document.querySelector('[data-scroll-stack]');
    const panel = root.querySelector('[data-care-scene]');
    const box = element => {
      const { x, y, width, height } = element.getBoundingClientRect();
      return { x, y, width, height };
    };
    return {
      y: scrollY,
      start: trigger?.start,
      end: trigger?.end,
      progress: trigger?.progress,
      animation: trigger?.animation.progress(),
      restoration: history.scrollRestoration,
      navigation: performance.getEntriesByType('navigation')[0].type,
      behavior: getComputedStyle(document.documentElement).scrollBehavior,
      inlineBehavior: document.documentElement.style.scrollBehavior,
      slots: root.querySelectorAll('[data-stack-slot]').length,
      triggers: ScrollTrigger.getAll().map(item => item.vars.id).sort(),
      layout: panel.dataset.careLayout,
      phase: panel.dataset.carePhase,
      panel: box(panel),
      cards: [...panel.querySelectorAll('[data-care-card]')].map(box),
    };
  });
}

function expectSameComposition(actual, expected) {
  expect(actual.restoration).toBe('auto');
  expect(Math.abs(actual.y - expected.y), 'scrollY após reload/retorno').toBeLessThanOrEqual(2);
  expect(actual.progress).toBeCloseTo(expected.progress, 2);
  expect(actual.animation).toBeCloseTo(expected.animation, 2);
  expect(actual.start).toBe(expected.start);
  expect(actual.end).toBe(expected.end);
  expect(actual.slots).toBe(expected.slots);
  expect(actual.triggers).toEqual(['sete-passos-care', 'sete-passos-scroll']);
  expect(actual.layout).toBe('deck');
  expect(actual.phase).toBe(expected.phase);
  expect(actual.cards).toHaveLength(4);
  [actual.panel, ...actual.cards].forEach((box, index) => {
    const reference = [expected.panel, ...expected.cards][index];
    for (const key of ['x', 'y', 'width', 'height']) {
      expect(Math.abs(box[key] - reference[key]), `panel/card ${index}: ${key}`).toBeLessThanOrEqual(2);
    }
  });
}

for (const entry of [
  { name: 'home', path: '/', slots: 5 },
]) {
  for (const progress of [.18, .53, .95]) {
    test(`reload de ${entry.name} preserva scroll e composição em ${progress * 100}%`, async ({ page }, testInfo) => {
      const errors = [];
      page.on('pageerror', error => errors.push(error.message));
      await page.goto(entry.path);
      const initial = await settledState(page);
      expect(initial.slots).toBe(entry.slots);
      expect(initial.end).toBeGreaterThan(initial.start);
      await page.evaluate(top => window.scrollTo({ top, behavior: 'instant' }),
        initial.start + progress * (initial.end - initial.start));
      const before = await settledState(page);
      expect(before.progress).toBeCloseTo(progress, 2);
      expect(before.animation).toBeCloseTo(progress, 2);

      await page.reload();
      const after = await settledState(page);
      await testInfo.attach('reload-scroll-state', {
        body: JSON.stringify({ path: entry.path, before, after, errors }, null, 2),
        contentType: 'application/json',
      });
      console.log('reload-scroll', JSON.stringify({
        path: entry.path, fraction: progress,
        before: { y: before.y, progress: before.progress, animation: before.animation },
        after: { y: after.y, progress: after.progress, animation: after.animation },
        behavior: after.behavior, inlineBehavior: after.inlineBehavior,
      }));
      expect(after.navigation).toBe('reload');
      expectSameComposition(after, before);

      // The restored home chapter must remain reversible.
      await page.evaluate(top => scrollTo({ top, behavior: 'instant' }), initial.start);
      const closed = await settledState(page);
      expect(closed.progress).toBe(0);
      expect(closed.animation).toBe(0);
      expect(closed.phase).toBe('stacked');
      await page.evaluate(top => scrollTo({ top, behavior: 'instant' }), before.y);
      expectSameComposition(await settledState(page), before);
      expect(errors).toEqual([]);
    });
  }
}
