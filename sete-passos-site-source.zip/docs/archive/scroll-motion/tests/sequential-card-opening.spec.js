// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });

async function sample(page) {
  return page.locator('[data-care-card]').evaluateAll(cards => cards.map(card => {
    const m = new DOMMatrix(getComputedStyle(card).transform);
    const r = card.getBoundingClientRect();
    return { x: r.x + r.width / 2, y: r.y + r.height / 2,
      scale: Math.hypot(m.a, m.b), angle: Math.atan2(m.b, m.a) * 180 / Math.PI,
      z: getComputedStyle(card).zIndex };
  }));
}
async function bounds(page) {
  return page.evaluate(async () => {
    const { layoutTop } = await import('/src/scroll-position.js');
    const panel = document.querySelector('#cuidado');
    const pin = Math.min(document.querySelector('.site-header').offsetHeight + 16, innerHeight - panel.offsetHeight - 24);
    return { start: layoutTop(panel) - pin, distance: parseFloat(getComputedStyle(panel.parentElement).paddingBottom) };
  });
}
async function seek(page, range, progress) {
  await page.evaluate(y => scrollTo({ top: y, behavior: 'instant' }), range.start + progress * range.distance);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return Boolean(ScrollTrigger.getById('sete-passos-care')?.getTween()?.isActive());
  })).toBe(false);
  return sample(page);
}

test('reload no meio mantém scroll restaurado e inicializa a mesma fase', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const range = await bounds(page);
  await seek(page, range, .6);
  const before = await sample(page);
  await page.reload();
  await page.evaluate(() => document.fonts.ready);
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return ScrollTrigger.getById('sete-passos-care')?.progress;
  })).toBeCloseTo(.6, 2);
  await expect.poll(async () => (await sample(page))[2].angle).toBeCloseTo(before[2].angle, 1);
});

test('fallback estreito ou baixo mantém os quatro cards no fluxo, sem fixar sua seção', async ({ page }) => {
  for (const viewport of [{ width: 1366, height: 768 }, { width: 768, height: 960 }, { width: 320, height: 740 }]) {
    await page.setViewportSize(viewport);
    await page.goto('/');
    await page.evaluate(() => document.fonts.ready);
    await expect(page.locator('#cuidado')).not.toHaveAttribute('data-care-layout', 'deck');
    await expect(page.locator('#cuidado')).toHaveCSS('transform', 'none');
    expect(await page.locator('#cuidado').evaluate(el => getComputedStyle(el.parentElement).paddingBottom)).toBe('0px');
    const cards = page.locator('[data-care-card]');
    await expect(cards).toHaveCount(4);
    for (const card of await cards.all()) {
      await expect(card).toHaveCSS('position', 'relative');
      await expect(card).toHaveCSS('transform', 'none');
      await card.locator('a').focus();
      await expect.poll(() => card.locator('a').evaluate(el => {
        const r = el.getBoundingClientRect();
        return el.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2));
      })).toBe(true);
    }
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  }
});

test('resize no meio preserva o progresso, sem recriar controladores duplicados', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  await seek(page, await bounds(page), .5);
  const progress = () => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return ScrollTrigger.getById('sete-passos-care')?.progress;
  });
  const before = await progress();
  await page.setViewportSize({ width: 1280, height: 1040 });
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  // Wait for the newly measured range, not a stale trigger from before resize.
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    const st = ScrollTrigger.getById('sete-passos-care');
    return st?.end - st?.start;
  })).toBe(1040 * 1.8);
  await expect.poll(progress).toBeCloseTo(before, 2);
  await expect.poll(() => page.evaluate(async () => {
    const { ScrollTrigger } = await import('/src/vendor/gsap.mjs');
    return ScrollTrigger.getAll().map(t => t.vars.id).sort();
  })).toEqual(['sete-passos-care', 'sete-passos-scroll']);
});

test('foco revela um card coberto antes do próximo frame, sem alterar sua camada', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  await seek(page, await bounds(page), 0);
  const result = await page.locator('[data-care-card]').nth(3).locator('a').evaluate(el => {
    const before = getComputedStyle(el.closest('[data-care-card]')).zIndex;
    el.focus({ preventScroll: true });
    const r = el.getBoundingClientRect();
    return { visible: el.contains(document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2)),
      phase: el.closest('#cuidado').dataset.carePhase, before,
      after: getComputedStyle(el.closest('[data-care-card]')).zIndex };
  });
  expect(result.visible).toBe(true);
  expect(result.phase).toBe('open');
  expect(result.after).toBe(result.before);
});

test('scrub acomoda somente os cards e para sem autoplay', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(async () => {
    await document.fonts.ready;
    const { gsap } = await import('/src/vendor/gsap.mjs');
    // Complete GSAP's 500ms startup window without polling its auto-sleeping ticker.
    await new Promise(resolve => gsap.delayedCall(.55, resolve));
  });
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const range = await bounds(page);
  await seek(page, range, 0);
  await page.evaluate(y => scrollTo({ top: y, behavior: 'instant' }), range.start + .55 * range.distance);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const moving = await sample(page);
  const pinnedY = await page.locator('#cuidado').evaluate(el => el.getBoundingClientRect().y);
  await expect.poll(async () => moving[2].x - (await sample(page))[2].x).toBeGreaterThan(5);
  const settled = await seek(page, range, .55);
  expect(await page.locator('#cuidado').evaluate(el => el.getBoundingClientRect().y)).toBeCloseTo(pinnedY, 1);
  await page.waitForTimeout(550);
  const stopped = await sample(page);
  expect(stopped).toEqual(settled);
});

test('saídas sequenciais sobrepostas revelam as camadas e percorrem o mesmo caminho inverso', async ({ page }) => {
  await page.goto('/');
  await page.evaluate(async () => {
    await document.fonts.ready;
    const { gsap } = await import('/src/vendor/gsap.mjs');
    // Complete GSAP's 500ms startup window without polling its auto-sleeping ticker.
    await new Promise(resolve => gsap.delayedCall(.55, resolve));
  });
  await expect(page.locator('#cuidado')).toHaveAttribute('data-care-layout', 'deck');
  const range = await bounds(page);
  const closed = await seek(page, range, 0);
  const early = await seek(page, range, .2);
  expect(closed[0].x - early[0].x).toBeGreaterThan(10);
  for (let i = 1; i < 4; i++) {
    expect(early[i].x).toBeCloseTo(closed[i].x, 1);
    expect(early[i].y).toBeCloseTo(closed[i].y, 1);
    expect(closed[i].scale).toBeLessThan(closed[i - 1].scale);
    expect(closed[i].x).toBeGreaterThan(closed[i - 1].x);
    expect(closed[i].y).toBeLessThan(closed[i - 1].y);
  }
  const phases = new Map([[0, closed], [.2, early]]);
  for (const progress of [.34, .5, .75, 1]) phases.set(progress, await seek(page, range, progress));
  expect(phases.get(.34)[1].x - closed[1].x).toBeGreaterThan(20);
  expect(phases.get(.34)[2].x).toBeCloseTo(closed[2].x, 1);
  expect(closed[2].x - phases.get(.5)[2].x).toBeGreaterThan(20);
  expect(phases.get(.5)[3].x).toBeCloseTo(closed[3].x, 1);
  expect(phases.get(.75)[3].x - closed[3].x).toBeGreaterThan(30);
  const open = phases.get(1);
  for (const [i, card] of open.entries()) {
    expect(card.scale).toBeGreaterThanOrEqual(.78);
    expect(card.scale).toBeLessThanOrEqual(.86);
    expect(Math.abs(card.angle)).toBeGreaterThanOrEqual(5);
    expect(Math.abs(card.angle)).toBeLessThanOrEqual(9);
    expect(i % 2 ? card.angle > 0 : card.angle < 0).toBe(true);
    expect(card.z).toBe(closed[i].z);
  }
  expect(open[0].x).toBeLessThan(open[1].x);
  expect(open[2].x).toBeLessThan(open[3].x);
  expect(open[0].y).toBeLessThan(open[2].y);
  expect(open[1].y).toBeLessThan(open[3].y);
  for (const progress of [.75, .5, .34, .2, 0]) {
    const reverse = await seek(page, range, progress);
    for (let i = 0; i < 4; i++) {
      for (const key of ['x', 'y', 'scale', 'angle']) expect(reverse[i][key]).toBeCloseTo(phases.get(progress)[i][key], 1);
      expect(reverse[i].z).toBe(closed[i].z);
    }
  }
});
