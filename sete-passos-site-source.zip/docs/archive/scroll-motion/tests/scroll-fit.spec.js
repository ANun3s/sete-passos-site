// A real per-test API isolates session probes from the user's development account.
import { test, expect } from '../auth-tests/profile-fixtures.mjs';

test.use({ baseURL: process.env.PORTAL_BASE_URL || 'http://127.0.0.1:5177' });

async function seek(page, top) {
  await page.evaluate(y => scrollTo({ top: y, behavior: 'instant' }), top);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
}

for (const width of [768, 1408]) {
  test(`seção inicial não reaparece depois dos cards em tela baixa de ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 684 });
    await page.goto('/');
    await page.evaluate(() => document.fonts.ready);
    await expect(page.locator('[data-scroll-stack]')).toHaveAttribute('data-stack-active', 'true');
    const position = await page.evaluate(async () => {
      const { layoutTop } = await import('/src/scroll-position.js');
      return layoutTop(document.querySelector('#essencia')) - innerHeight * .72;
    });
    let first;
    for (const y of [position, position + 160, position]) {
      await seek(page, y);
      const boxes = await page.evaluate(() => {
        const hero = document.querySelector('[data-stack-slot]:first-child .scroll-stack-card').getBoundingClientRect();
        const care = document.querySelector('#cuidado').getBoundingClientRect();
        const content = document.querySelector('.hero');
        // The opening now contains the emblem and actions, not an editorial
        // footnote. Neither the mark nor action glyphs may leak past the seam.
        const range = document.createRange(); range.selectNodeContents(document.querySelector('.hero-actions'));
        const rects = [...range.getClientRects(), document.querySelector('.hero-logo').getBoundingClientRect()];
        const exposed = rects.some(rect => {
          const x = rect.x + rect.width / 2, y = rect.y + rect.height / 2;
          return y > 0 && y < innerHeight && content.contains(document.elementFromPoint(x, y));
        });
        return { heroBottom: hero.bottom, careBottom: care.bottom, exposed };
      });
      expect(boxes.heroBottom).toBeLessThanOrEqual(boxes.careBottom + 1);
      expect(boxes.exposed).toBe(false);
      if (!first) first = boxes;
      else if (y === position) expect(boxes).toEqual(first);
    }
  });
}
